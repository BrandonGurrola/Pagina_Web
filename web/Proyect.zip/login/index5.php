<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style2.css">
    <title></title>
</head>
<body>
<form name="form" action="registro.php" method="post">
    <section class="form-register">
    <h4>Registro</h4>
    <input class="controls" type="text" name="nombres" id="nombres"  placeholder="Ingrese su nombre">
    <input class="controls" type="text" name="apellidos" id="apellidos" placeholder="Ingrese sus apellidos">
    <input class="controls" type="text" name="correo" id="correo" placeholder="Ingrese su correo">
    <input class="controls" type="password" name="password" id="password" placeholder="Ingrese su password">
    <p> Estoy de acuerdo con <a href="#"> Terminos y condiciones </a></p>
    <input class="botons" type="submit" value="Registrar">
    <input class="botons" type="reset" value="Borrar">
    <p><a href="#">¿Ya tengo cuenta?</a></p>


   </section>
</form>
</body>
</html>

